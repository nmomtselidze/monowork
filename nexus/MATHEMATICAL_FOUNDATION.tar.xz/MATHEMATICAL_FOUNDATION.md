# Mathematical Foundation of Nexus (Object Engineering)

Authors: Ph.D. N.Momtselidze with AI assistance

## Overview

Nexus is a multi-agent workflow orchestration system built on the mathematical foundation of **Directed Acyclic Graphs (DAGs)**. This document provides a rigorous mathematical explanation of the core concepts, algorithms, and properties that enable Nexus to orchestrate complex workflows efficiently.

---

## 1. Graph Theory Foundation

### 1.1 Definition of a Directed Graph

A **directed graph** \( G = (V, E) \) consists of:

- \( V \): A finite set of vertices (nodes)
- \( E \): A set of ordered pairs \( (u, v) \) where \( u, v \in V \), called edges

In Nexus:
- \( V \) represents the set of agents: \( V = \{a_1, a_2, \ldots, a_n\} \)
- \( E \) represents dependencies between agents: \( E = \{(a_i, a_j) \mid a_i \text{ must complete before } a_j\} \)

### 1.2 Directed Acyclic Graph (DAG)

A **Directed Acyclic Graph** is a directed graph with no directed cycles. Formally:

A graph \( G = (V, E) \) is acyclic if there exists no sequence of vertices \( v_1, v_2, \ldots, v_k \) such that:
- \( (v_i, v_{i+1}) \in E \) for all \( i = 1, 2, \ldots, k-1 \)
- \( v_1 = v_k \)

**Mathematical Property:** DAGs are partially ordered sets where the relation is the transitive closure of the edge relation.

### 1.3 Topological Ordering

A **topological ordering** of a DAG \( G = (V, E) \) is a linear ordering \( \pi: V \to \{1, 2, \ldots, |V|\} \) such that for every edge \( (u, v) \in E \):

\[
\pi(u) < \pi(v)
\]

This means all predecessors of a node appear before the node in the ordering.

**Existence Theorem:** Every DAG has at least one topological ordering.

---

## 2. Node and Edge Representation

### 2.1 Node Structure

Each node (agent) in Nexus is represented as:

\[
N_i = \{id_i, name_i, type_i, config_i, status_i, t_{created}^i, t_{started}^i, t_{completed}^i\}
\]

Where:
- \( id_i \): Unique identifier
- \( name_i \): Human-readable name
- \( type_i \): Agent type (processor, transformer, validator, aggregator)
- \( config_i \): Configuration parameters \( config_i: K \to V \)
- \( status_i \in \{idle, running, completed, failed\} \)
- \( t_{created}^i, t_{started}^i, t_{completed}^i \): Timestamps

### 2.2 Edge Structure

Each edge represents a dependency with weight:

\[
E_{ij} = \{from_i, to_j, w_{ij}\}
\]

Where:
- \( from_i \): Source node ID
- \( to_j \): Target node ID
- \( w_{ij} \in \mathbb{R}^+ \): Edge weight (priority or cost)

The adjacency matrix representation is:

\[
A_{ij} = \begin{cases}
w_{ij} & \text{if } (i, j) \in E \\
0 & \text{otherwise}
\end{cases}
\]

### 2.3 In-Degree and Out-Degree

For a node \( v \):

- **In-degree** \( \deg^-(v) = |\{u \in V \mid (u, v) \in E\}| \)
- **Out-degree** \( \deg^+(v) = |\{u \in V \mid (v, u) \in E\}| \)

**Root nodes:** \( \deg^-(v) = 0 \)

**Leaf nodes:** \( \deg^+(v) = 0 \)

---

## 3. Cycle Detection Algorithm

### 3.1 Depth-First Search (DFS) Based Detection

Nexus uses DFS with a recursion stack to detect cycles. The algorithm maintains two sets:

- \( V_{visited} \): Set of visited nodes
- \( V_{recursion} \): Set of nodes in the current recursion stack

**Algorithm:**

```
function hasCycle(G = (V, E)):
    for each v ∈ V:
        if v ∉ V_visited:
            if dfsCycleCheck(v):
                return true
    return false

function dfsCycleCheck(v):
    V_visited ← V_visited ∪ {v}
    V_recursion ← V_recursion ∪ {v}
    
    for each (v, u) ∈ E:
        if u ∉ V_visited:
            if dfsCycleCheck(u):
                return true
        else if u ∈ V_recursion:
            return true
    
    V_recursion ← V_recursion \ {v}
    return false
```

### 3.2 Mathematical Complexity

- **Time Complexity:** \( O(|V| + |E|) \)
  - Each node is visited once: \( O(|V|) \)
  - Each edge is examined once: \( O(|E|) \)

- **Space Complexity:** \( O(|V|) \)
  - Recursion stack can hold at most \( |V| \) nodes

---

## 4. Topological Sorting (Kahn's Algorithm)

### 4.1 Algorithm Description

Kahn's algorithm computes a topological ordering by iteratively removing nodes with zero in-degree.

**Algorithm:**

```
function topologicalSort(G = (V, E)):
    // Compute in-degrees
    for each v ∈ V:
        deg⁻(v) ← 0
    
    for each (u, v) ∈ E:
        deg⁻(v) ← deg⁻(v) + 1
    
    // Initialize queue with zero in-degree nodes
    Q ← {v ∈ V | deg⁻(v) = 0}
    result ← []
    
    while Q ≠ ∅:
        v ← dequeue(Q)
        result ← result ∪ {v}
        
        for each (v, u) ∈ E:
            deg⁻(u) ← deg⁻(u) - 1
            if deg⁻(u) = 0:
                enqueue(Q, u)
    
    if |result| ≠ |V|:
        return error (cycle detected)
    
    return result
```

### 4.2 Mathematical Correctness

**Invariant:** At each iteration, the queue \( Q \) contains exactly the set of nodes whose all predecessors have been added to the result.

**Proof Sketch:**
1. Initially, \( Q \) contains all nodes with \( \deg^-(v) = 0 \) (no predecessors)
2. When a node \( v \) is removed from \( Q \), all its successors have their in-degree decremented
3. A successor \( u \) is added to \( Q \) only when all its predecessors have been processed
4. Thus, when \( u \) is added to \( Q \), all its dependencies are in the result
5. By induction, the result maintains the topological ordering property

### 4.3 Complexity Analysis

- **Time Complexity:** \( O(|V| + |E|) \)
  - Computing in-degrees: \( O(|E|) \)
  - Processing each node: \( O(|V|) \)
  - Processing each edge: \( O(|E|) \)

- **Space Complexity:** \( O(|V|) \)
  - In-degree array: \( O(|V|) \)
  - Queue: \( O(|V|) \)

---

## 5. Parallel Execution Optimization

### 5.1 Critical Path Analysis

The **critical path** is the longest path from a root node to a leaf node in the DAG. It determines the minimum execution time.

For a path \( P = (v_1, v_2, \ldots, v_k) \):

\[
T(P) = \sum_{i=1}^{k} t(v_i)
\]

Where \( t(v_i) \) is the execution time of node \( v_i \).

The critical path length:

\[
T_{critical} = \max_{P \in \text{Paths}(G)} T(P)
\]

### 5.2 Level-Based Parallelization

Nodes can be partitioned into **levels** based on their distance from root nodes:

\[
\text{level}(v) = \max_{(u, v) \in E} \text{level}(u) + 1
\]

Nodes at the same level can be executed in parallel.

**Example:**
```
Level 0: {A, B}  (root nodes)
Level 1: {C, D}  (depend on A or B)
Level 2: {E}     (depends on C and D)
```

### 5.3 Speedup Analysis

Let:
- \( T_{seq} \): Sequential execution time
- \( T_{par} \): Parallel execution time
- \( P \): Number of processors
- \( L \): Number of levels

**Theoretical Speedup:**

\[
S = \frac{T_{seq}}{T_{par}} \leq \min(P, L)
\]

**Amdahl's Law:**

\[
S = \frac{1}{(1 - f) + \frac{f}{P}}
\]

Where \( f \) is the fraction of the execution that can be parallelized.

### 5.4 Work Conservation

In Nexus, parallel execution is work-conserving: it schedules all ready nodes (those with zero in-degree) whenever resources are available.

The scheduler maintains:

\[
R = \{v \in V \mid \deg^-(v) = 0 \land v \text{ not completed}\}
\]

The set \( R \) is updated dynamically as nodes complete.

---

## 6. Agent Execution Semantics

### 6.1 Execution Function

Each agent implements an execution function:

\[
f_i: \mathbb{I} \to \mathbb{O}
\]

Where:
- \( \mathbb{I} \): Input space
- \( \mathbb{O} \): Output space

For an agent \( a_i \):

\[
\text{Execute}(a_i, x) = f_i(x)
\]

### 6.2 State Transition

Agent state transitions form a Markov chain:

\[
S = \{idle, running, completed, failed\}
\]

Transition probabilities (deterministic in Nexus):

\[
P(s_{t+1} = \text{running} \mid s_t = \text{idle}) = 1
\]
\[
P(s_{t+1} = \text{completed} \mid s_t = \text{running}, \text{success}) = 1
\]
\[
P(s_{t+1} = \text{failed} \mid s_t = \text{running}, \text{error}) = 1
\]

### 6.3 Result Aggregation

For an aggregator agent with inputs \( \{x_1, x_2, \ldots, x_n\} \):

\[
\text{Aggregate}(x_1, \ldots, x_n) = \bigoplus_{i=1}^{n} x_i
\]

Where \( \bigoplus \) is the aggregation operation (sum, concatenate, merge, etc.).

---

## 7. Workflow Composition

### 7.1 Workflow Definition

A workflow \( W \) is defined as:

\[
W = (G, A, \phi)
\]

Where:
- \( G = (V, E) \): DAG structure
- \( A = \{a_1, a_2, \ldots, a_n\} \): Set of agents
- \( \phi: V \to A \): Mapping from nodes to agents

### 7.2 Execution Semantics

Sequential execution:

\[
\text{ExecuteSequential}(W, x) = f_{\pi(n)}(f_{\pi(n-1)}(\ldots f_{\pi(1)}(x)\ldots))
\]

Where \( \pi \) is the topological ordering.

Parallel execution:

\[
\text{ExecuteParallel}(W, x) = \bigotimes_{i=1}^{n} f_i(x_i)
\]

Where \( \bigotimes \) denotes parallel composition respecting dependencies.

### 7.3 Dependency Resolution

For a node \( v \) with dependencies \( D(v) = \{u \mid (u, v) \in E\} \):

\[
\text{Input}(v) = \{\text{Output}(u) \mid u \in D(v)\}
\]

The node executes only when all dependencies are satisfied:

\[
\text{CanExecute}(v) \iff \forall u \in D(v): \text{Status}(u) = \text{completed}
\]

---

## 8. Performance Metrics

### 8.1 Execution Time

For node \( v_i \):

\[
t_i = t_{completed}^i - t_{started}^i
\]

Total workflow time:

\[
T_{total} = \max_{v \in V} t_{completed}^v - \min_{v \in V} t_{started}^v
\]

### 8.2 Throughput

Throughput \( \tau \) (nodes per second):

\[
\tau = \frac{|V|}{T_{total}}
\]

### 8.3 Utilization

Processor utilization \( U \):

\[
U = \frac{\sum_{i=1}^{n} t_i}{P \cdot T_{total}}
\]

Where \( P \) is the number of processors.

---

## 9. Complexity Summary

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| Add Node | \( O(1) \) | \( O(1) \) |
| Add Edge | \( O(|V| + |E|) \) | \( O(|V|) \) |
| Cycle Detection | \( O(|V| + |E|) \) | \( O(|V|) \) |
| Topological Sort | \( O(|V| + |E|) \) | \( O(|V|) \) |
| Sequential Execution | \( O(\sum t_i) \) | \( O(|V|) \) |
| Parallel Execution | \( O(T_{critical}) \) | \( O(|V|) \) |

---

## 10. Mathematical Properties

### 10.1 Determinism

Given a DAG \( G \) and input \( x \), the output is deterministic:

\[
\text{Execute}(G, x) = y \implies \text{Execute}(G, x) = y \quad \forall \text{executions}
\]

### 10.2 Termination

For any finite DAG \( G \) and finite agent execution times, the workflow terminates:

\[
\forall v \in V: t_v < \infty \implies T_{total} < \infty
\]

### 10.3 Partial Order Consistency

The topological ordering respects the partial order defined by the DAG:

\[
(u, v) \in E \implies \pi(u) < \pi(v)
\]

### 10.4 Critical Path Lower Bound

The parallel execution time is bounded below by the critical path:

\[
T_{par} \geq T_{critical}
\]

---

## 11. Advanced Concepts

### 11.1 Graph Transitive Closure

The transitive closure \( G^* = (V, E^*) \) includes all indirect dependencies:

\[
E^* = \{(u, v) \mid \exists \text{ path } u \to v \text{ in } G\}
\]

Computationally: \( O(|V|^3) \) using Floyd-Warshall, or \( O(|V| \cdot |E|) \) using DFS from each node.

### 11.2 Longest Path in DAG

The longest path can be computed in \( O(|V| + |E|) \) using topological sort:

```
function longestPath(G = (V, E)):
    order ← topologicalSort(G)
    dist[v] ← 0 for all v ∈ V
    
    for each v in order:
        for each (v, u) ∈ E:
            if dist[v] + w(v, u) > dist[u]:
                dist[u] ← dist[v] + w(v, u)
    
    return max(dist)
```

### 11.3 Reachability Matrix

The reachability matrix \( R \) indicates if node \( i \) can reach node \( j \):

\[
R_{ij} = \begin{cases}
1 & \text{if } \exists \text{ path } i \to j \\
0 & \text{otherwise}
\end{cases}
\]

---

## 12. Conclusion

Nexus leverages fundamental graph theory concepts to provide a robust workflow orchestration framework:

1. **DAG Structure**: Ensures no circular dependencies
2. **Topological Sorting**: Guarantees valid execution order
3. **Cycle Detection**: Prevents invalid workflow definitions
4. **Parallel Execution**: Optimizes performance while respecting dependencies
5. **Agent Model**: Provides a flexible, composable execution unit

The mathematical foundation ensures correctness, efficiency, and predictability in workflow execution, making Nexus suitable for complex multi-agent systems including CI/CD pipelines, ETL workflows, and ML pipelines.

---

## References

1. Cormen, T. H., Leiserson, C. E., Rivest, R. L., & Stein, C. (2009). *Introduction to Algorithms* (3rd ed.). MIT Press.
2. Kahn, A. B. (1962). Topological sorting of large networks. *Communications of the ACM*, 5(11), 558-562.
3. Tarjan, R. E. (1972). Depth-first search and linear graph algorithms. *SIAM Journal on Computing*, 1(2), 146-160.
4. Amdahl, G. M. (1967). Validity of the single processor approach to achieving large scale computing capabilities. *AFIPS Conference Proceedings*, 30, 483-485.
