from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors

def create_monowork_pdf():
    doc = SimpleDocTemplate("monowork_explanation.pdf", pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    title = Paragraph("Monowork Workspace Overview", styles["Title"])
    story.append(title)
    story.append(Spacer(1, 12))

    intro = Paragraph(
        "Monowork is a multi-project workspace focused on AI/ML development, "
        "workflow orchestration, and tensor engineering.",
        styles["BodyText"]
    )
    story.append(intro)
    story.append(Spacer(1, 12))

    # Table data - split into multiple rows for better formatting
    data = [
        ["Project", "Description", "Technologies"],
        ["nexus", "Multi-Agent Graph System", "Go, DAGs"],
        ["", "DAG-based workflow orchestration for CI/CD, ML pipelines, and ETL", ""],
        ["", "Go-based with parallel execution and 49.9% test coverage", ""],
        ["tensor_ml_project", "Production-ready ML system", "Python, PyTorch,\nTransformers"],
        ["", "Advanced tensor operations, transformer architecture", ""],
        ["", "Real data training with evaluation and visualization", ""],
        ["harness2_engineering", "Gemini command-line implementations", "Go, Rust,\nGemini API"],
        ["", "AI/ML integration and API development", ""],
        ["SDML_pro", "Disease Symptoms ML project", "Python, PyTorch,\nTransformers"],
        ["", "GPT-2 for symptom prediction", ""],
        ["", "Trains on HuggingFace dataset", ""],
        ["trip-planner-crew", "Autonomous trip planning system", "Python, Agents"],
        ["", "Mathematical foundation explanations", ""],
        ["", "Agent-based coordination", ""],
        ["adk_production", "Agent Development Kit projects", "Python, Go, ADK"],
        ["", "Building intelligent agents", ""],
        ["", "Python and Go implementations", ""],
    ]

    # Create table with narrower Project column and wider Description column
    table = Table(data, colWidths=[1.8*72, 4.6*72, 1.6*72])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('WORDWRAP', (0, 0), (-1, -1), 'LTR'),
        # Vertical lines
        ('LINEBEFORE', (1, 0), (1, -1), 1, colors.black),
        ('LINEBEFORE', (2, 0), (2, -1), 1, colors.black),
        # Horizontal lines between projects (after nexus row 3, tensor row 6, harness row 8, SDML row 11, trip row 14)
        ('LINEABOVE', (0, 4), (-1, 4), 1, colors.black),
        ('LINEABOVE', (0, 7), (-1, 7), 1, colors.black),
        ('LINEABOVE', (0, 9), (-1, 9), 1, colors.black),
        ('LINEABOVE', (0, 12), (-1, 12), 1, colors.black),
        ('LINEABOVE', (0, 15), (-1, 15), 1, colors.black),
    ]))

    story.append(table)
    story.append(Spacer(1, 12))

    purpose = Paragraph(
        "<b>Purpose:</b> Demonstrates expertise in modern AI development, from multi-agent systems to production ML deployment.",
        styles["BodyText"]
    )
    story.append(purpose)

    doc.build(story)
    print("PDF created: monowork_explanation.pdf")

if __name__ == "__main__":
    create_monowork_pdf()
